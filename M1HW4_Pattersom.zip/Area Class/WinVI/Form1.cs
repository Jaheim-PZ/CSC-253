﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


/**
* 8/29/2021
* CSC 253
* Jaheim Patterson
* This program calculates the area of a rectangle.
*/
namespace WinVI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            int width = Convert.ToInt32(txtWidth.Text);
            int lemgth = Convert.ToInt32(txtLength.Text);
            int area = (width * lemgth);
            txtResult.Text = "Area: " + area;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtWidth.Clear();
            txtLength.Clear();
            txtResult.Clear();
        }
    }
}
