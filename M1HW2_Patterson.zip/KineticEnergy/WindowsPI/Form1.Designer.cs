﻿
namespace WindowsPI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Mass_lbl = new System.Windows.Forms.Label();
            this.Velocity_lbl = new System.Windows.Forms.Label();
            this.Mass_txt = new System.Windows.Forms.TextBox();
            this.Kinetic_txt = new System.Windows.Forms.TextBox();
            this.Calculate_Button = new System.Windows.Forms.Button();
            this.Kinetic_lbl = new System.Windows.Forms.Label();
            this.Velocity_txt = new System.Windows.Forms.TextBox();
            this.Exit_button = new System.Windows.Forms.Button();
            this.Clear_Button = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Mass_lbl
            // 
            this.Mass_lbl.AutoSize = true;
            this.Mass_lbl.Location = new System.Drawing.Point(67, 21);
            this.Mass_lbl.Name = "Mass_lbl";
            this.Mass_lbl.Size = new System.Drawing.Size(41, 17);
            this.Mass_lbl.TabIndex = 0;
            this.Mass_lbl.Text = "Mass";
            // 
            // Velocity_lbl
            // 
            this.Velocity_lbl.AutoSize = true;
            this.Velocity_lbl.Location = new System.Drawing.Point(67, 93);
            this.Velocity_lbl.Name = "Velocity_lbl";
            this.Velocity_lbl.Size = new System.Drawing.Size(57, 17);
            this.Velocity_lbl.TabIndex = 1;
            this.Velocity_lbl.Text = "Velocity";
            // 
            // Mass_txt
            // 
            this.Mass_txt.Location = new System.Drawing.Point(137, 21);
            this.Mass_txt.Name = "Mass_txt";
            this.Mass_txt.Size = new System.Drawing.Size(100, 22);
            this.Mass_txt.TabIndex = 2;
            // 
            // Kinetic_txt
            // 
            this.Kinetic_txt.Location = new System.Drawing.Point(137, 174);
            this.Kinetic_txt.Name = "Kinetic_txt";
            this.Kinetic_txt.Size = new System.Drawing.Size(100, 22);
            this.Kinetic_txt.TabIndex = 3;
            // 
            // Calculate_Button
            // 
            this.Calculate_Button.Location = new System.Drawing.Point(405, 21);
            this.Calculate_Button.Name = "Calculate_Button";
            this.Calculate_Button.Size = new System.Drawing.Size(75, 23);
            this.Calculate_Button.TabIndex = 4;
            this.Calculate_Button.Text = "Calcualte";
            this.Calculate_Button.UseVisualStyleBackColor = true;
            this.Calculate_Button.Click += new System.EventHandler(this.Calculate_Button_Click);
            // 
            // Kinetic_lbl
            // 
            this.Kinetic_lbl.AutoSize = true;
            this.Kinetic_lbl.Location = new System.Drawing.Point(32, 177);
            this.Kinetic_lbl.Name = "Kinetic_lbl";
            this.Kinetic_lbl.Size = new System.Drawing.Size(99, 17);
            this.Kinetic_lbl.TabIndex = 5;
            this.Kinetic_lbl.Text = "Kinetic Energy";
            // 
            // Velocity_txt
            // 
            this.Velocity_txt.Location = new System.Drawing.Point(137, 88);
            this.Velocity_txt.Name = "Velocity_txt";
            this.Velocity_txt.Size = new System.Drawing.Size(100, 22);
            this.Velocity_txt.TabIndex = 6;
            // 
            // Exit_button
            // 
            this.Exit_button.Location = new System.Drawing.Point(405, 93);
            this.Exit_button.Name = "Exit_button";
            this.Exit_button.Size = new System.Drawing.Size(75, 23);
            this.Exit_button.TabIndex = 7;
            this.Exit_button.Text = "Exit";
            this.Exit_button.UseVisualStyleBackColor = true;
            this.Exit_button.Click += new System.EventHandler(this.Exit_button_Click);
            // 
            // Clear_Button
            // 
            this.Clear_Button.Location = new System.Drawing.Point(405, 177);
            this.Clear_Button.Name = "Clear_Button";
            this.Clear_Button.Size = new System.Drawing.Size(75, 23);
            this.Clear_Button.TabIndex = 8;
            this.Clear_Button.Text = "Clear";
            this.Clear_Button.UseVisualStyleBackColor = true;
            this.Clear_Button.Click += new System.EventHandler(this.Clear_Button_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Clear_Button);
            this.Controls.Add(this.Exit_button);
            this.Controls.Add(this.Velocity_txt);
            this.Controls.Add(this.Kinetic_lbl);
            this.Controls.Add(this.Calculate_Button);
            this.Controls.Add(this.Kinetic_txt);
            this.Controls.Add(this.Mass_txt);
            this.Controls.Add(this.Velocity_lbl);
            this.Controls.Add(this.Mass_lbl);
            this.Name = "Form1";
            this.Text = "Kinetic Energy";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Mass_lbl;
        private System.Windows.Forms.Label Velocity_lbl;
        private System.Windows.Forms.TextBox Mass_txt;
        private System.Windows.Forms.TextBox Kinetic_txt;
        private System.Windows.Forms.Button Calculate_Button;
        private System.Windows.Forms.Label Kinetic_lbl;
        private System.Windows.Forms.TextBox Velocity_txt;
        private System.Windows.Forms.Button Exit_button;
        private System.Windows.Forms.Button Clear_Button;
    }
}

