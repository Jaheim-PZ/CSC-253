﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;



/**
* 8/21/2021
* CSC 253
* Jaheim Patterson
* This program to allows you to enter the mass and velocity of an item and calculate how much kinetic energy that it has.
*/



namespace WindowsPI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Calculate_Button_Click(object sender, EventArgs e)
        {
            double m;
            double v;

            if (double.TryParse(Mass_txt.Text, out m) && double.TryParse(Velocity_txt.Text, out v))
            {
                double KEN = KineticEnergy(m, v);
                Kinetic_txt.Text = KEN.ToString("n");
            }
            else
                MessageBox.Show("Enter valid number please!");
        }
        private double KineticEnergy(double m, double v)
        {
            double KEN = 0.5 * m * Math.Pow(v, 2);
            return KEN;
        }

        private void Clear_Button_Click(object sender, EventArgs e)
        {
            Mass_txt.Clear();
            Velocity_txt.Clear();
            Kinetic_txt.Clear();
        }

        private void Exit_button_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
