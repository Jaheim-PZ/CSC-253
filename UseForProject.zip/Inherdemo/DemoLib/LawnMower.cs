﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoLib
{
    public class LawnMower : IRepairWork
    {
        public LawnMower(int bladeLength, string owner, int id)
        {
            BladeLength = bladeLength;
            Owner = owner;
            ID = id;
        }
        public int BladeLength { get; set; }
        public string Owner { get; set; }
        public int ID { get; set ; }
    }
}
