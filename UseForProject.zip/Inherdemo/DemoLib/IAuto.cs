﻿namespace DemoLib
{
    public interface IAuto
    {
        int Doors { get; set; }
        string Make { get; set; }
        string Model { get; set; }
        decimal Price { get; set; }
    }
}