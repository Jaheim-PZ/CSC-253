﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoLib
{
    public abstract class Auto : IAuto
    {
        // Parent Class
        public Auto(int doors, string make, string model, decimal price)
        {
            Doors = doors;
            Make = make;
            Model = model;
            Price = price;

        }

        public int Doors { get; set; }
        public string Make { get; set; }
        public string Model { get; set; }
        public decimal Price { get; set; }


        public abstract string MakeSound();

    }
}
