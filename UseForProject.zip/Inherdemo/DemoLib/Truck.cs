﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoLib
{
    public class Truck : Auto, IRepairWork
    {
        public Truck(int doors, string make, string model, decimal price, double bedSize, int id) : base(doors, make, model, price)
        {
            BedSize = bedSize;
            ID = id;
        }

        public double BedSize { get; set; }
        public int ID { get ; set ; }

        public override string MakeSound()
        {
            return "Rumble, rumble";
        }
    }
}