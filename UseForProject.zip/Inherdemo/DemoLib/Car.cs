﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoLib
{
    public class Car : Auto, IRepairWork
    {
        public Car(int doors, string make, string model, decimal price, double trunkSpace, int id ): base(doors, make, model, price)
        {
            TrunkSpace = trunkSpace;
            ID = id;
        }

        public double TrunkSpace { get; set; }
        public int ID { get; set; }

        public override string MakeSound()
        {
            return "Zip, zip";
        }

       
    }
}
