﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DemoLib;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            Car myCar = new Car(4, "Ford", "Escort", 35000, 10, 003);
            Truck myTruck = new Truck(2, "Dodge", "Ram", 37000, 6, 002);
            LawnMower myMower = new LawnMower(42, "William", 001);

            List<IRepairWork> autos = new List<IRepairWork>();

            autos.Add(myCar);
            autos.Add(myTruck);
            autos.Add(myMower);

            //Console.WriteLine(myAuto.MakeSound());
            Console.WriteLine(myCar.MakeSound());
            Console.WriteLine(myTruck.MakeSound());







            Console.ReadLine();
        }
    }
}
