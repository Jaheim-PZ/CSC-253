﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinRNFR
{
    public class Reader
    {
        public static string MakeDocument(String input)
        {
            try
            {
                return "Save complete";
            }
            catch(Exception ex)
            {
                String y = ex.Message;
                return y;
            }
        }
    }
}
