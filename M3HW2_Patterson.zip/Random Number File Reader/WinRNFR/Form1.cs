﻿using System.IO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
* 9/19/2021
* CSC 253
* Jaheim Patterson
* This uses OpenFileDialog to open the file from Random Number File Writer.
*/

namespace WinRNFR
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnOpen_Click(object sender, EventArgs e)
        {
            try
            {
                int num = 0;
                int count = 0;
                int sum = 0;

                OpenFileDialog openFile = new OpenFileDialog();
                openFile.ShowDialog();
                string filePath = openFile.FileName;

                StreamReader inputFile = File.OpenText(filePath);

                txtResuly.Text = ("File loaded: " + filePath);
                lstResult.Items.Add("#\tRnd#\tTotal");

                while (!inputFile.EndOfStream)
                {
                    num = int.Parse(inputFile.ReadLine());
                    count = count + 1;
                    sum = num + sum;
                    lstResult.Items.Add(count + "\t" + num + "\t" + sum);

                }
                inputFile.Close();
                txtResuly.Text = count.ToString();
                txtResuly.Text = sum.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            lstResult.Items.Clear();
            txtResuly.Clear();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
