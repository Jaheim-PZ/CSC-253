﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


/**
* 9/12/2021
* CSC 253
* Jaheim Patterson
* This program gets the most frequent character in a string that you enter.
*/


namespace WinMFC
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

       
        private void btnCalc_Click(object sender, EventArgs e)
        {

            txtResult.Text = ("Most frequent character is: ");
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtResult.Clear();
            txtString.Clear();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
