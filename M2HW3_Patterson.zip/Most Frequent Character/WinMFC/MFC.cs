﻿using LanguageExt.ClassInstances.Const;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;




namespace WinMFC
{
    public class MFC
    {
        private static char[] GitMostFrequentCharacter(string str)
        {
            Dictionary<char, int> characs = new Dictionary<char, int>();

            foreach (char c in str)
            {
                if (characs.ContainsKey(c)) characs[c]++;

                else characs.Add(c, 1);
            }

            int max = characs.Values.Max();

            return characs.Where(b => b.Value == max).Select(b => b.Key).ToArray();
        }
    }
    
}
