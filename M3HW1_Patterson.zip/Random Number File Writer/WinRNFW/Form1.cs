﻿using System.IO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
* 9/19/2021
* CSC 253
* Jaheim Patterson
* This program creates a file that allows you to chose a random number from 1-100.
*/


namespace WinRNFW
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                StreamWriter numFile;
                System.Windows.Forms.SaveFileDialog saveFile1 = new System.Windows.Forms.SaveFileDialog();
                int ranNum = 0;
                int amount  = int.Parse(txtResult.Text.ToString());
                int count = 1;

                
                SaveFileDialog saveFile;

                

                saveFile1.FileName = "numFile.txt";

                
                if (saveFile1.ShowDialog() == DialogResult.OK) ;

                numFile = File.AppendText(saveFile1.FileName);

                Random rand = new Random();

                while(count <= amount)
                {
                    
                    numFile.WriteLine("Random Number " + count + " is: " + ranNum + " \r\n");
                    count++;
                }

            }
            catch(Exception ex)
            {
                MessageBox.Show("You did something wrong try again!");
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtResult.Clear();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        
    }
}
