﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


/**
* 9/5/2021
* CSC 253
* Jaheim Pattetson
* This program counts all the words that you place within a sentence.
*/
namespace WinWC
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnResult_Click(object sender, EventArgs e)
        {
            string words = txtWords.Text.Trim();
            string[] allWords = words.Split(' ');
            txtCount.Text = ("Number of words: " + allWords.Length);
            


        }

       

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtCount.Clear();
            txtWords.Clear();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
