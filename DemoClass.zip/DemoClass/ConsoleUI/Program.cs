﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DemoClassLibrary;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            /**
            * OVERVIEW -----------------------------------------------------
            *
            * C# is an object-oriented language. What this means is that
            * Object-oriented programming (OOP) refers to a type of computer 
            * programming (software design) in which programmers define not 
            * only the data type of a data structure, but also the types of 
            * operations (functions) that can be applied to the data structure.
            *
            * In this way, the data structure becomes an object that includes both 
            * data and functions. In addition, programmers can create relationships 
            * between one object and another. For example, objects can inherit 
            * characteristics from other objects.
            *
            * This is the long way of saying that you will be creating and using objects
            * in your program. The main way to do this is by creating a class that
            * you will instantiate (create) an object from. First you need to
            * how to make a class.
            *
            * Think of a "Class" as a blueprint. It is not the object itself but
            * what will be used to model the object from.
            */

            /**
            * INFO #1 --------------------------------------------------------
            *
            * Like with all programs from here on out you will first need to
            * create a class Library. Give it a meaningful name, for this
            * Demo I will name it "DemoLibrary". Add the "DemoLibrary" to this
            * project's "References" then add the "using" statement to this file.
            *
            * If you do not remember how to do this please review Module 5 Demos.
            *
            * Add a class to the "DemoLibrary" called "DemoClass"
            *
            * In the "DemoClass" find "CLASSOVERVIEW".
            */

            /**
             * INFO #2---------------------------------------------------------
             * 
             * Now that we have created the "Class" we can create objects from
             * that "Class". The first example will be using the default 
             * constructor and then trying to print out its values.
             * 
             * The second is using a "Parameterized Constructor" and printing
             * all the values there. Just like with methods values must be passed
             * in the order of the parameters in the constructor.
             * 
             * To create the object first call the datatype, in this case is the
             * "Class" name. Then give the object a name like with variables. Next
             * comes the "new" key word then the "Class" name again follow with
             * arguments inside () if there are any.
             */

            DemoClass bob = new DemoClass();

            Console.WriteLine(bob.FirstName);
            Console.WriteLine(bob.MiddleName);
            Console.WriteLine(bob.LastName);
            Console.WriteLine(bob.Age);

            /**
             * INFO #3 ----------------------------------------------------------
             * 
             * To add values to the fields you must call the Object name then
             * the property.
             */

            bob.FirstName = "Bob";
            bob.MiddleName = "Thomas";
            bob.LastName = "Blake";
            bob.Age = 25;

            Console.WriteLine(bob.FirstName);
            Console.WriteLine(bob.MiddleName);
            Console.WriteLine(bob.LastName);
            Console.WriteLine(bob.Age);

            // With Arguments
            DemoClass tom = new DemoClass("Thomas", "Bob", "Blake", 27);

            Console.WriteLine(tom.FirstName);
            Console.WriteLine(tom.MiddleName);
            Console.WriteLine(tom.LastName);
            Console.WriteLine(tom.Age);

            /**
             * INFO #4 --------------------------------------------------
             * 
             * Use the "Class" method to make changes
             * First passing an "int" the second passes a string to view
             * that the OverLoad works.
             */

            bob.AddToAge(5);
            tom.AddToAge("5");

            Console.WriteLine(bob.FirstName);
            Console.WriteLine(bob.MiddleName);
            Console.WriteLine(bob.LastName);
            Console.WriteLine(bob.Age);

            Console.WriteLine(tom.FirstName);
            Console.WriteLine(tom.MiddleName);
            Console.WriteLine(tom.LastName);
            Console.WriteLine(tom.Age);


            Console.ReadLine();

        }
    }
}
