﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProblemClass
{
    public class Customer : Person
    {
        public Customer(string name, string address, int phone, int customerNum) : base(name, address, phone)
        {
            ShiftNumm = customerNum;
        }

        public int ShiftNumm { get; set; }

        public override string ToString()
        {
            return "My Customer Number: " + ShiftNumm + "\r\n";
        }
    }
}
