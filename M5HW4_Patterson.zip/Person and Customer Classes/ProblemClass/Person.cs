﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProblemClass
{
    public class Person
    {
        public Person(string name, string address, int phone)
        {
            myName = name;

            myAddress = address;

            myPhone = phone;
        }

        public string myName { get; set; }

        public string myAddress { get; set; }

        public int myPhone { get; set; }

        public override string ToString()
        {
            return "My Name: " + myName + "\r\n" + "My Address: " + myAddress + "\r\n" + "My Phone: " + myPhone + "\r\n";

        }
    }
}
