﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ProblemClass;
namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnShow_Click(object sender, EventArgs e)
        {
            string name = txtName.Text;

            string address = txtAddress.Text;

            int phone = Convert.ToInt32(txtPhone.Text);

            int customerNum = Convert.ToInt32(txtCustomer.Text);

            Customer worker = new Customer(name, address, phone, customerNum);

            lblAddress.Text = worker.ToString();

            lblCustomer.Text = worker.ToString();

            lblName.Text = worker.ToString();

            lblPhone.Text = worker.ToString();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtName.Clear();

            txtCustomer.Clear();

            txtAddress.Clear();

            txtPhone.Clear();

            lblAddress.Text = "";

            lblCustomer.Text = "";

            lblName.Text = "";

            lblPhone.Text = "";
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
