﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


/**
* 10/2/2021
* CSC 253
* Jaheim Patterson
* Sorts hourly pay rate by acscending or descendind order.
*/

namespace WinHT
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'personelDataSet1.Employee' table. You can move, or remove it, as needed.
            this.employeeTableAdapter.Fill(this.personelDataSet1.Employee);
            

        }

        private void btn_Ascend_Click(object sender, EventArgs e)
        {
            
        }
    }
}
