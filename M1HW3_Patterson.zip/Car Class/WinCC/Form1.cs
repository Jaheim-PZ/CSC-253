﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


/**
* 8/29/2021
* CSC 253
* Jaheim Patterson
* This program allows you to calculate the speed of a car after it accelerates or decelerates. I also allows to to enter the type of car ans the year that it was made.
*/
namespace WinCC
{
    public partial class Form1 : Form
    {
        private Car myCar;
        public Form1()
        {
            myCar = new Car();
            InitializeComponent();
        }

        private void GetCarData()
        {
            try
            {
                myCar.Make = txtMake.Text;
                myCar.Year = int.Parse(txtYear.Text);
                myCar.Speed = 0;
            }
            catch(Exception ex)
            {
                MessageBox.Show("Must enter a valid make and yeatr for the car!");
            }
        }
        private void btnShow_Click(object sender, EventArgs e)
        {
            GetCarData();
            myCar.Acceleration(5);
            MessageBox.Show("Your car is a " + myCar.Year + myCar.Make + "and is moving at " + myCar.Speed + "mph");

        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtMake.Clear();
            txtSpeed.Clear();
            txtYear.Clear();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnDecele_Click(object sender, EventArgs e)
        {
            GetCarData();
            myCar.Deceleration(5);
            MessageBox.Show("Your car is a " + myCar.Year + myCar.Make + "and is moving at " + myCar.Speed + "mph");
        }
    }
}
