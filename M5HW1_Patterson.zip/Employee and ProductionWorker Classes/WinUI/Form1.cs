﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Employee_Class;

/**
* 10/24/2021
* CSC 253
* Jaheim Patterson
* This program allows the user to enter in employee information and worker information and displays it in txt boxes and labels.
*/

namespace WinUI


{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void btnShow_Click(object sender, EventArgs e)
        {
            string name = txtName.Text;

            int number = Convert.ToInt32(txtNumber.Text);

            int shift = Convert.ToInt32(txtShift.Text);

            decimal pay = Convert.ToDecimal(txtHPR.Text);

            Production_Worker worker = new Production_Worker(name, number, shift, pay);

            lblHPR.Text = worker.ToString();

            lblName.Text = worker.ToString();

            lblHPR.Text = worker.ToString();

            lblNum.Text = worker.ToString();


            
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtHPR.Clear();
            txtName.Clear();
            txtNumber.Clear();
            txtShift.Clear();
            lblHPR.Text = "";
            lblName.Text = "";
            lblNum.Text = "";
            lblShift.Text = "";
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
