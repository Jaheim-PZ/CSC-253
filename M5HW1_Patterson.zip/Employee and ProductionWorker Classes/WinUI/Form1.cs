﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void GetEmployeeInfo(EmployeeInfo info)
        {
            int ShiftNum;
            decimal PayRate;

            info.Number = txtNumber.Text;

            info.ShiftNum = txtShift.Text;

            
        }

        private void btnShow_Click(object sender, EventArgs e)
        {

        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtHPR.Clear();
            txtName.Clear();
            txtNumber.Clear();
            txtShift.Clear();
            lblHPR.Text = "";
            lblName.Text = "";
            lblNum.Text = "";
            lblShift.Text = "";
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
