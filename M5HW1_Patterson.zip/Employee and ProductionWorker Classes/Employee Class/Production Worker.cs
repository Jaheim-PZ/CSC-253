﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee_Class
{
    class Production_Worker:EmployeeInfo
    {
        public Production_Worker()
        {
            int ShiftNum;
            decimal PayRate;
        }

        public int ShiftNum { get; set; }
        public decimal PayRate { get; set; }
    }
}
