﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee_Class
{
    class EmployeeInfo
    {
        public EmployeeInfo()
        {
            string Name;

            int Number;
        }
        public string Name { get; set; }

        public int Number { get; set; }
        
    }
}
