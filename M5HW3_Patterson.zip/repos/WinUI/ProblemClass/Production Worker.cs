﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProblemClass
{
    public class Production_Worker : TeamLeader
    {
        public Production_Worker(string name, int number, int shift, decimal pay, double bonusAmount, double trainingHours, double attendedTraining) : base(bonusAmount, trainingHours, attendedTraining)
        {
            ShiftNum = shift;
            PayRate = pay;
        }

        public int ShiftNum { get; set; }
        public decimal PayRate { get; set; }

        public override string ToString()
        {
            return base.ToString() +
                "Shift Number: " + ShiftNum + "\r\n" +
                "Pay Rate: " + PayRate + "\r\n";
        }
    }
}
