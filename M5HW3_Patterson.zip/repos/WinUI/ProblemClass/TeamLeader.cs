﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProblemClass
{
    public class TeamLeader
    {
        public TeamLeader(double bonusAmount, double trainingHours, double attendedTraining)
        {
            myBonusAmount = bonusAmount;

            myTrainingHours = trainingHours;

            myAttendedTraining = attendedTraining;
        }
        public double myBonusAmount { get; set; }

        public double myTrainingHours { get; set; }

        public double myAttendedTraining { get; set;}

        public override string ToString()
        {
            return "My Bonus: " + myBonusAmount + "\r\n" + "My Training Hours: " + myTrainingHours + "\r\n" + "My Attended Training: " + myAttendedTraining + "\r\n";
        }
    }
}
