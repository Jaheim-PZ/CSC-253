﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProblemClass
{
    public class EmployeeInfo
    {
        public EmployeeInfo(string name, int number)
        {
            myName = name;

            myNumber = number;
        }
        public string myName { get; set; }

        public int myNumber { get; set; }

        public override string ToString()
        {
            return "My Name: " + myName + "\r\n" + "My Numeber: " + myNumber + "\r\n";
        }

    }
}