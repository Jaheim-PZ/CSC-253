﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ProblemClass;

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnShow_Click(object sender, EventArgs e)
        {
            string name = txtName.Text;

            int number = Convert.ToInt32(txtNumber.Text);

            int shift = Convert.ToInt32(txtShift.Text);

            decimal pay = Convert.ToDecimal(txtHPR.Text);

            decimal bonusAmount = Convert.ToDecimal(txtBonus);

            int trainingHours = Convert.ToInt32(txtTraining);

            double attendedTraining = Convert.ToDouble(txtAttended);

            Production_Worker worker = new Production_Worker(name, number, shift, pay, bonusAmount, trainingHours, attendedTraining);

            lblHPR.Text = worker.ToString();

            lblName.Text = worker.ToString();

            lblHPR.Text = worker.ToString();

            lblNumber.Text = worker.ToString();

            lblAttended.Text = worker.ToString();

            lblBonus.Text = worker.ToString();

            lblTraining.Text = worker.ToString();


        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtAttended.Clear();
            txtBonus.Clear();
            txtHPR.Clear();
            txtName.Clear();
            txtNumber.Clear();
            txtShift.Clear();
            txtTraining.Clear();
            lblAttended.Text = "";
            lblBonus.Text = "";
            lblHPR.Text = "";
            lblName.Text = "";
            lblNumber.Text = "";
            lblShift.Text = "";
            lblTraining.Text = "";
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
