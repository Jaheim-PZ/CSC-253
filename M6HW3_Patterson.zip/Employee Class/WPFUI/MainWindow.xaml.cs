﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using EmployeeInfo;

namespace WPFUI
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void ButtonAddName_Click(object sender, RoutedEventArgs e)
        {
            string name = txtName1.Text;
            int id = Convert.ToInt32(txtID.Text);
            int shift = Convert.ToInt32(txtShift.Text);
            decimal pay = Convert.ToDecimal(txtPay.Text);

            PWorker worker = new PWorker(name, id, shift, pay);

            lstResult.Items.Add("Employee Name: " + (name));

            lstResult.Items.Add("Employee ID: " + (id));

            lstResult.Items.Add("Shift: " + (shift));

            lstResult.Items.Add("Pay: " + (pay));
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            txtID.Clear();

            txtPay.Clear();

            txtShift.Clear();

            lstResult.Items.Clear();

            txtName1.Clear();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
