﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeInfo
{
    public class PWorker : EmpInfo
    {
        public PWorker(string name, int id, int shift, decimal hourly_pay) : base(name, id)
        {
            Shift = shift;
            Hourlypay = hourly_pay;
        }

        public int Shift { get; set; }
        public decimal Hourlypay { get; set; }

        public override string ToString()
        {
            return base.ToString() + "Shift: " + Shift + "\r\n"
                + "Hourly pay: " + Hourlypay + "\r\n";
        }
    }
}