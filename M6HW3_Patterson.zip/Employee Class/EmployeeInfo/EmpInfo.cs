﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeInfo
{
    public class EmpInfo
    {
        public EmpInfo(string name, int id)
        {
            employee_name = name;
            employee_id = id;
        }
        public string employee_name { get; set; }
        public int employee_id { get; set; }

        public override string ToString()
        {
            return "Employee Name: " + employee_name + "\r\n"
                + "Employee ID: " + employee_id + "\r\n";
        }
    }
}
