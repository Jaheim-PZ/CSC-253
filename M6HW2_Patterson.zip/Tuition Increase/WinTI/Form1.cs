﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
* 11/13/2021
* CSC 253
* Jaheim Patterson
* This program takes the tuition incease for 5 years and turns it into a unit test.
*/

namespace WinTI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            string display;

            double intialFee = 6000.00;

            double increase, newFee;

            double rate = 0.02;

            for(int year = 1; year <= 5; year++)
            {
                increase = intialFee * rate * year;

                newFee = increase + intialFee;

                display = "Year: " + year.ToString() + " Amount " + "$" + newFee;

                lstResult.Items.Add(display);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            lstResult.Items.Clear();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
