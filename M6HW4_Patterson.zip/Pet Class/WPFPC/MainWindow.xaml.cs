﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Pet_Items;

namespace WPFPC
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        public MainWindow(string name, string type, decimal age)
        {
            this.name = name;
            this.type = type;
            this.age = age;
        }

        MainWindow Pet;
        private string name;
        private string type;
        private decimal age;

        private void ButtonAddName_Click(object sender, RoutedEventArgs e)
        {
            string name = txtName.Text;

            string type = txtType.Text;

            decimal age = Convert.ToDecimal(txtAge.Text);



            Pet = new MainWindow(name, type, age);

            lstResult.Items.Add("Pet Name: " + (name));

            lstResult.Items.Add("Pet Type: " + (type));

            lstResult.Items.Add("Pet Age: " + (age));

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            txtAge.Clear();

            txtType.Clear();

            txtName.Clear();

            lstResult.Items.Clear();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
