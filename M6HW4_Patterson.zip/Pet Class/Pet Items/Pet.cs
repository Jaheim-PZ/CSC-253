﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pet_Items
{
    public class Pet
    {
        public Pet(string name, string type, decimal age)
        {

            petName = name;

            petType = type;

            petAge = age;

        }

        public string petName { get; set; }

        public string petType { get; set; }

        public decimal petAge { get; set; }

    }
}
