﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


/**
* 9/12/2021
* CSC 253
* Jaheim Patterson
* This program seperates strings that are clumped together.
*/


namespace WinWS
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            string text = txtString.Text;

            int upperCase;

            foreach(char up in text)
            {
                if (char.IsUpper(up))
                {
                    upperCase = text.IndexOf(up);

                    text = text.Insert(upperCase, " ");
                }
            }
            text = text.ToLower();

            text = text[1].ToString().ToUpper() + text.Substring(2);

            txtResult.Text = text;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtResult.Clear();
            
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
