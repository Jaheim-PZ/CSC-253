﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ShiftSupervisor;

/**
* 10/24/2021
* CSC 253
* Jaheim Patterson
* This program deproves from Employee and Productin Worker class and puts more emphasis on finding the calculation for the annual salary and production bonuses.
*/


namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnShow_Click(object sender, EventArgs e)
        {
            string name = txtName.Text;

            int number = Convert.ToInt32(txtNumber.Text);

            int shift = Convert.ToInt32(txtShift.Text);

            decimal pay = Convert.ToDecimal(txtHPR.Text);

            decimal salary = Convert.ToDecimal(txtSalary.Text);

            double bonus = Convert.ToDouble(txtBonus.Text);

            Production_Worker worker = new Production_Worker(name, number, shift, pay, salary, bonus);

            lblBonus.Text = worker.ToString();

            lblSalary.Text = worker.ToString();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtBonus.Clear();
            txtHPR.Clear();
            txtName.Clear();
            txtNumber.Clear();
            txtSalary.Clear();
            txtShift.Clear();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

       
    }
}
