﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShiftSupervisor
{
    public class Supervisor
    {
        public Supervisor(decimal salary, double bonus)
        {
            mySalary = salary;

            myBonus = bonus;
        }
        public decimal mySalary { get; set; }

        public double myBonus { get; set; }

        public override string ToString()
        {
            return "My Salary: " + mySalary + "\r\n" + "My Bonus: " + myBonus + "\r\n";
        }
    }
}
