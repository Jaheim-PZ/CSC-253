﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Engine.Models
{
    public class Rodent
    {
        private string Name { get; set; }
        private string Password { get; set; }
        private string CharacterClass { get; set; }
        private string CharacterRace { get; set; }

        ///HELLO
        ////public string Name
        ////{
        ////    get { return _name; }
        ////    set
        ////    {
        ////        _name = value;
        ////        OnPropertyChanged("Name");
        ////    }
        ////}

        ////public string CharacterClass
        ////{
        ////    get { return _characterClass; }
        ////    set
        ////    {
        ////        _characterClass = value;
        ////        OnPropertyChanged("CharacterClass");
        ////    }
        ////}
        
        ////public int Level
        ////{
        ////    get { return _level; }
        ////    set
        ////    {
        ////        _level = value;
        ////        OnPropertyChanged("Level");
        ////    }
        ////}


    }
}

