﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using WindowsET;

namespace UnitTestProject1
{
    [TestClass]
    public class RetailTests
    {
        [TestMethod]
        public void Reatial_withValidAmount_UpdateBalance(double wholesale, double markup, double retailPrice)
        {


        }
    }
}
