﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
* Date
* CSC 253
* Jaheim Patterson
* This program takes the Retail Proce calcualtor project and turns it into a unit test.
*/

namespace WindowsET
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Calculate_Button_Click(object sender, EventArgs e)
        {
            double wholesale;
            double markup;

            if (double.TryParse(txt_Cost.Text, out wholesale) && double.TryParse(txt_Percentage.Text, out markup))
            {
                double retailPrice;
                retailPrice = CalculateRetail(wholesale, markup);
                lbl_Result.Text = retailPrice.ToString("C");
            }
            else
                MessageBox.Show("Please enter valid numbers", "Invalid input");
        }

        private double CalculateRetail(double wholesale, double markup)
        {
            double markUpPercent = markup / 100;
            double retailPrice;

            retailPrice = wholesale + (wholesale + markUpPercent);
            return retailPrice;
        }

        private void Clear_Button_Click(object sender, EventArgs e)
        {
            txt_Cost.Clear();
            txt_Percentage.Clear();
            lbl_Result.Text = "";
        }

        private void Exit_Button_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
