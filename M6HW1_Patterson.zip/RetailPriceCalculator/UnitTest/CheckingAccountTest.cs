﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WindowsET;

namespace UnitTest
{
    public class CheckingAccountTest
    {
        double m_blance;

        public void Withdeaw(double amount)
        {
            if(m_blance >= amount)
            {
                m_blance -= amount;
            }
            else
            {
                throw new ArgumentException(nameof(amount), "Withdrawal exceeds balance!");
            }
        }
    }
}
