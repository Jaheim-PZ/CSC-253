﻿
namespace RetailPriceCalculator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.WholeSale = new System.Windows.Forms.Label();
            this.MarkUp = new System.Windows.Forms.Label();
            this.RetailPe = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.btnCalc = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // WholeSale
            // 
            this.WholeSale.AutoSize = true;
            this.WholeSale.Location = new System.Drawing.Point(30, 25);
            this.WholeSale.Name = "WholeSale";
            this.WholeSale.Size = new System.Drawing.Size(148, 17);
            this.WholeSale.TabIndex = 0;
            this.WholeSale.Text = "Enter Wholesale Cost:";
            // 
            // MarkUp
            // 
            this.MarkUp.AutoSize = true;
            this.MarkUp.Location = new System.Drawing.Point(30, 97);
            this.MarkUp.Name = "MarkUp";
            this.MarkUp.Size = new System.Drawing.Size(174, 17);
            this.MarkUp.TabIndex = 1;
            this.MarkUp.Text = "Enter Markup Percentage:";
            // 
            // RetailPe
            // 
            this.RetailPe.AutoSize = true;
            this.RetailPe.Location = new System.Drawing.Point(30, 208);
            this.RetailPe.Name = "RetailPe";
            this.RetailPe.Size = new System.Drawing.Size(80, 17);
            this.RetailPe.TabIndex = 2;
            this.RetailPe.Text = "Retail Price";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(184, 25);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 22);
            this.textBox1.TabIndex = 3;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(210, 94);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 22);
            this.textBox2.TabIndex = 4;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(116, 208);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 22);
            this.textBox3.TabIndex = 5;
            this.textBox3.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // btnCalc
            // 
            this.btnCalc.Location = new System.Drawing.Point(49, 143);
            this.btnCalc.Name = "btnCalc";
            this.btnCalc.Size = new System.Drawing.Size(153, 31);
            this.btnCalc.TabIndex = 6;
            this.btnCalc.Text = "Calculate Retail Price";
            this.btnCalc.UseVisualStyleBackColor = true;
            this.btnCalc.Click += new System.EventHandler(this.btnCalc_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnCalc);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.RetailPe);
            this.Controls.Add(this.MarkUp);
            this.Controls.Add(this.WholeSale);
            this.Name = "Form1";
            this.Text = "Retail Price Calc";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label WholeSale;
        private System.Windows.Forms.Label MarkUp;
        private System.Windows.Forms.Label RetailPe;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Button btnCalc;
    }
}

