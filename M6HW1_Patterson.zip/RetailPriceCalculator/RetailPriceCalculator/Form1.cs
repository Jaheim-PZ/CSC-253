﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RetailPriceCalculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            double wholesale;
            double markup;

            if (double.TryParse(WholeSale.Text, out wholesale) && double.TryParse(MarkUp.Text, out markup))
            {
                double retailPrice;
                retailPrice = CalculateRetail(wholesale, markup);
                RetailPe.Text = retailPrice.ToString("C");
            }
            else
                MessageBox.Show("Enter actual good numbers.", "Try Again.");
        }
        private double CalculateRetail(double wholesale, double markup)
        {
            double markupPercent = markup / 100;
            double retailPrice;

            retailPrice = wholesale + (wholesale * markupPercent);
            return retailPrice;
        }
    }
}
