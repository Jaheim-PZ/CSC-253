﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


/**
* 9/5/2021
* CSC 253
* Jaheim Patterson
* This program displays the average amount of letters per word.
*/


namespace WinAVL
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnResult_Click(object sender, EventArgs e)
        {
            string words = txtLetters.Text.Trim();
            string[] allWords = words.Split(' ');
            int result2 = words.Split('a').Length - 1;
            txtletCount.Text = ("Number of letters: " + words.Length);
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtletCount.Clear();
            txtLetters.Clear();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
