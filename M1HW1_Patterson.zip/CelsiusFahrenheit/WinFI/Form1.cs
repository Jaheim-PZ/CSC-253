﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


/**
* 8/21/2021
* CSC 253
* Jaheim Patterson
* This program coverts celcius to farenheight from 0 to 100. This program is very good to use if you seek to calculate from the metric to the imperial system
* and vice versa. 
*/



namespace WinFI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void ShowTable_Click(object sender, EventArgs e)
        {
            const int MIN_TEMPERATURE = 0;
            const int MAX_TEMPERATURE = 100;
            decimal f;

            for (int i = MIN_TEMPERATURE; i <=MAX_TEMPERATURE; i++)
            {
                f = (9m / 5) * i + 32;
                listBox1.Items.Add("\t" + i + "\t\t" + f);
            }
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            this.Close();
       }
    }
}
